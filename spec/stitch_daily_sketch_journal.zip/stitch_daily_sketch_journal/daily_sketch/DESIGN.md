---
name: Daily Sketch
colors:
  surface: '#fff8f3'
  surface-dim: '#e0d9d3'
  surface-bright: '#fff8f3'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#faf2ec'
  surface-container: '#f4ece7'
  surface-container-high: '#eee7e1'
  surface-container-highest: '#e9e1db'
  on-surface: '#1e1b18'
  on-surface-variant: '#464840'
  inverse-surface: '#33302c'
  inverse-on-surface: '#f7efe9'
  outline: '#76786f'
  outline-variant: '#c7c7bd'
  surface-tint: '#5b614e'
  primary: '#585e4c'
  on-primary: '#ffffff'
  primary-container: '#717763'
  on-primary-container: '#faffe8'
  inverse-primary: '#c3c9b2'
  secondary: '#5f5e5b'
  on-secondary: '#ffffff'
  secondary-container: '#e5e2dd'
  on-secondary-container: '#656461'
  tertiary: '#5e5c56'
  on-tertiary: '#ffffff'
  tertiary-container: '#77746e'
  on-tertiary-container: '#fffbff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dfe5cd'
  primary-fixed-dim: '#c3c9b2'
  on-primary-fixed: '#181d0f'
  on-primary-fixed-variant: '#434937'
  secondary-fixed: '#e5e2dd'
  secondary-fixed-dim: '#c9c6c2'
  on-secondary-fixed: '#1c1c19'
  on-secondary-fixed-variant: '#474743'
  tertiary-fixed: '#e7e2da'
  tertiary-fixed-dim: '#cac6be'
  on-tertiary-fixed: '#1d1c17'
  on-tertiary-fixed-variant: '#494741'
  background: '#fff8f3'
  on-background: '#1e1b18'
  surface-variant: '#e9e1db'
typography:
  display:
    fontFamily: Inter
    fontSize: 34px
    fontWeight: '700'
    lineHeight: 41px
    letterSpacing: 0.4px
  headline:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 30px
    letterSpacing: 0.3px
  headline-mobile:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 25px
    letterSpacing: 0.3px
  body-lg:
    fontFamily: Inter
    fontSize: 17px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: -0.4px
  body-sm:
    fontFamily: Inter
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: -0.2px
  label-caps:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.8px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  container-margin: 24px
  stack-gap-lg: 32px
  stack-gap-md: 16px
  stack-gap-sm: 8px
  section-padding: 40px
---

## Brand & Style
The design system for this product is centered on the concept of a "digital sanctuary" for creativity. It prioritizes the artist's focus by minimizing UI noise and maximizing visual breathing room. The brand personality is quiet, intentional, and premium, evoking the tactile feel of high-end stationery or a physical sketchbook. 

Drawing from **Modern Minimalism** and **Apple’s Human Interface Guidelines**, the aesthetic leverages high-quality whitespace and refined typography. The emotional response should be one of calm focus—removing the pressure of "sharing" or "engagement" common in social platforms, and replacing it with the intrinsic joy of the creative process.

## Colors
The palette is built on a foundation of warm neutrals to simulate natural paper and canvas. The **Primary** color is a muted Sage, used sparingly for meaningful actions and active states. 

- **Backgrounds:** Use a soft Cream (`#F5F2ED`) in light mode and a deep, desaturated Charcoal-Warm Gray in dark mode. Avoid pure black.
- **Surfaces:** Secondary and tertiary neutrals provide depth without harsh contrast, creating a "layered paper" effect.
- **Accents:** The Sage green is the only functional color, used for primary buttons and selection indicators. 
- **Dark Mode:** Transition to a low-contrast scheme where the background is a warm dark gray and text is an off-white to reduce eye strain during late-night sketching.

## Typography
This design system utilizes **Inter** (as a highly accessible web-safe equivalent to SF Pro) to maintain a systematic, clean look. 

- **Generous Leading:** All body text utilizes expanded line heights to enhance legibility and reinforce the "calm" aesthetic.
- **Tracking:** Headlines and labels use slightly increased letter spacing (tracking) to create a premium, editorial feel. 
- **Hierarchy:** Contrast is achieved through weight and spacing rather than color. `label-caps` is used for category headers or metadata to provide a structured, organized feel to the creative journal.

## Layout & Spacing
The layout follows a **Fluid Grid** model optimized for mobile-first interaction. 

- **Safe Margins:** A standard 24px horizontal margin is maintained across all screens to ensure content does not feel crowded against the edge of the device.
- **Vertical Rhythm:** Large 40px gaps are used between major sections (e.g., between the date header and the sketch gallery) to emphasize whitespace as a design element.
- **Composition:** Content should be centered or use asymmetrical balance to mimic a physical journal layout. Avoid dense grids; opt for single or double-column views that give each "sketch" room to breathe.

## Elevation & Depth
Depth is conveyed through **Tonal Layers** rather than heavy shadows, adhering to a modern SwiftUI aesthetic.

- **Stacking:** Elements are layered using subtle shifts in background color (e.g., a slightly darker cream card on a lighter cream background).
- **Shadows:** When necessary, use extremely soft, diffused ambient shadows (`blur: 20px, opacity: 0.05, color: #4A4642`) to lift primary cards.
- **Glassmorphism:** Use background blurs (Ultra Thin Material) for navigation bars and toolbars to maintain a sense of context and light as the user scrolls.

## Shapes
The shape language is defined by **Large Radii**, creating a soft and approachable interface. 

- **Cards & Large Containers:** Use a 24px or 32px radius (`rounded-xl` or larger) to frame sketches.
- **Buttons:** Use fully rounded (pill-shaped) or 16px radius corners to ensure they feel comfortable to the touch.
- **Interactive Elements:** Input fields and chips should mirror the card radii to maintain a cohesive, "liquid" geometric language.

## Components
- **Buttons:** Primary buttons use a solid Sage fill with white or cream text. Secondary buttons use a tonal background (Tertiary Neutral) with Sage text. No borders.
- **Sketch Cards:** These are the centerpiece. Use 24px corner radii, minimal padding, and high-quality image previews. Metadata (date/title) should be placed in `body-sm` or `label-caps` below the card.
- **Toolbars:** Use translucent background blurs. Icons should be thin-stroke (SF Symbols style) to maintain a lightweight feel.
- **Inputs:** Text fields are borderless with a subtle tonal background fill. Focus states are indicated by a soft Sage glow or a subtle 1pt weight increase in the underline.
- **Navigation:** A simple bottom tab bar with labels only appearing for the active state to reduce visual clutter.